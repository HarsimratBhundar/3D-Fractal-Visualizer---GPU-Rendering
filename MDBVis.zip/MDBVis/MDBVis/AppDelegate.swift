//
//  AppDelegate.swift
//  MDBVis
//
//  Created by Harsimrat Bhundar on 15/05/17.
//  Copyright © 2017 Harsimrat Bhundar. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
    }

    func applicationWillTerminate(_ aNotification: Notification) {
    }


}

